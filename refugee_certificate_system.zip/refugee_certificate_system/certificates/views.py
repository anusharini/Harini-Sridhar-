from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Certificate
from django.contrib.auth.decorators import login_required
import qrcode
from io import BytesIO
from reportlab.pdfgen import canvas
import time
from .forms import IssueCertificateForm
from web3 import Web3 # type: ignore

# Load contract
contract_address = '0x9dd61d9c68823E5884E7909285620D3B0FB7561d'
contract_abi = [
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "recipient",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "refugeeName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "countryName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "dateOfBirth",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "addres",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "gender",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "certificateId",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "issueDate",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "validUntil",
				"type": "string"
			}
		],
		"name": "issueCertificate",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"name": "certificateIds",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "certificates",
		"outputs": [
			{
				"internalType": "string",
				"name": "refugeeName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "countryName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "dateOfBirth",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "addres",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "gender",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "certificateId",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "issueDate",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "validUntil",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "generatedBy",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "recipient",
				"type": "address"
			}
		],
		"name": "verifyCertificateByAddress",
		"outputs": [
			{
				"internalType": "string",
				"name": "refugeeName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "countryName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "dateOfBirth",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "addres",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "gender",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "certificateId",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "issueDate",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "validUntil",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "generatedBy",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "certificateId",
				"type": "string"
			}
		],
		"name": "verifyCertificateById",
		"outputs": [
			{
				"internalType": "string",
				"name": "refugeeName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "countryName",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "dateOfBirth",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "addres",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "gender",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "certId",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "issueDate",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "validUntil",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "generatedBy",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]

# Initialize Web3
ganache_url = 'http://127.0.0.1:7545'
web3 = Web3(Web3.HTTPProvider(ganache_url))
contract = web3.eth.contract(address=contract_address, abi=contract_abi)

#different pages

def home(request):
    return render(request, 'home.html')

def about_us(request):
    return render(request, 'about_us.html')

def features(request):
    return render(request,'features.html')

def whyus(request):
    return render(request,'why-us.html')

def our_team(request):
    return render(request, 'our_team.html')

def how_we_work(request):
    return render(request, 'how_we_work.html')


def download_app(request):
    return render(request, 'download_app.html')

#
@login_required
def issue_certificate(request):
    if request.method == 'POST':
        form = IssueCertificateForm(request.POST)
        if form.is_valid():
            recipient = form.cleaned_data['recipient_address']
            refname=form.cleaned_data['refugee_name']
            cerdata=form.cleaned_data['certificate_data']
            add=form.cleaned_data['address']
            valuntil=form.cleaned_data['valid_until']
            dob=form.cleaned_data['date_of_birth']
            refcount=form.cleaned_data['country']
            issdate=form.cleaned_data['issuing_date']
            gend=form.cleaned_data['gender']

            certificate_data = {
                "certificate_data": form.cleaned_data['certificate_data'],
                "valid_until": form.cleaned_data['valid_until'],
                "issuing_date": form.cleaned_data['issuing_date'],
                "address": form.cleaned_data['address'],
                "refugee_name": form.cleaned_data['refugee_name'],
                "date_of_birth": form.cleaned_data['date_of_birth'],
                "country": form.cleaned_data['country'],
                "gender": form.cleaned_data['gender'],
            }
            certificate_id = f"REF-{form.cleaned_data['refugee_name'][:3].upper()}-{int(time.time())}"

            refugee=Certificate.objects.create(refugee_name=refname,country_name=refcount,date_of_birth=dob,address=add,gender=gend,certificate_id=certificate_id,valid_until=valuntil,issue_date=issdate,generated_by=request.user)
            #form.save()

            # Call the smart contract function to issue the certificate
            tx_hash = contract.functions.issueCertificate(recipient,form.cleaned_data['refugee_name'],form.cleaned_data['country'],str(form.cleaned_data['date_of_birth']),form.cleaned_data['address'],form.cleaned_data['gender'],str(certificate_id),str(form.cleaned_data['issuing_date']),str(form.cleaned_data['valid_until'])).transact({'from': web3.eth.accounts[0]})

            # Wait for the transaction receipt
            receipt = web3.eth.wait_for_transaction_receipt(tx_hash)


            return render(request, 'certificates/certificate_confirmation.html', {
            'certificate_id': certificate_id,
            'refugee_name': form.cleaned_data['refugee_name'],
            'valid_until': form.cleaned_data['valid_until']})
    else:
        form = IssueCertificateForm()
    return render(request,'certificates/generate_certificate.html')

@login_required
def generate_certificate(request):
    if request.method == 'POST':
        refugee_name = request.POST.get('refugee_name')
        valid_until = request.POST.get('valid_until')
        certificate_id = f"REF-{refugee_name[:3].upper()}-{int(time.time())}"
        certificate = Certificate(
            refugee_name=refugee_name,
            certificate_id=certificate_id,
            valid_until=valid_until,
            generated_by=request.user
        )
        certificate.save()
        return render(request, 'certificates/certificate_confirmation.html', {
            'certificate_id': certificate.certificate_id,
            'refugee_name': refugee_name,
            'valid_until': valid_until
        })
    return render(request, 'certificates/generate_certificate.html')

def validate_certificate(request):
    refugee_name = None
    certificate_id = None
    valid_until = None

    if request.method == 'POST':
        certificate_id = request.POST.get('certificate_id')
        certificate = get_object_or_404(Certificate, certificate_id=certificate_id)
        refugee_name = certificate.refugee_name
        valid_until = certificate.valid_until

    context = {
        'refugee_name': refugee_name,
        'certificate_id': certificate_id,
        'valid_until': valid_until,
    }
    
    return render(request, 'certificates/validated_certificate.html', context)



from io import BytesIO
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.units import inch
import qrcode

#pdf border
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Add this to your try block before building elements
from reportlab.pdfgen import canvas

def draw_border(canvas):
    canvas.setStrokeColor(colors.darkblue)
    canvas.setLineWidth(5)
    canvas.rect(50, 50, 500, 700, stroke=1, fill=0)

# Add a hook for drawing the border
    

def generate_pdf_certificate(request, certificate_id):
    certificate = get_object_or_404(Certificate, certificate_id=certificate_id)

    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Center', alignment=1, fontSize=16, textColor=colors.black, spaceAfter=12))
    styles.add(ParagraphStyle(name='Body', fontSize=12, textColor=colors.black, spaceAfter=10))

    elements = []

    try:
        # Header
        elements.append(Paragraph("CertifyChain", styles['Title']))
        elements.append(Paragraph("Empowering Refugees Through Secure and Verifiable Certificates", styles['Center']))
        elements.append(Spacer(1, 0.5 * inch))

        # Certificate Title
        title = Paragraph("Refugee Certificate", styles['Title'])
        elements.append(title)
        elements.append(Spacer(1, 0.5 * inch))

        # Certificate Body
        elements.append(Paragraph("This is to certify that", styles['Center']))
        elements.append(Paragraph(f"<b>{certificate.refugee_name}</b>", styles['Center']))
        elements.append(Paragraph("has been officially recognized as a refugee.", styles['Center']))
        elements.append(Spacer(1, 0.5 * inch))

        elements.append(Paragraph("Details:", styles['Center']))
        elements.append(Spacer(1, 0.25 * inch))
        elements.append(Paragraph(f"Certificate ID: <b>{certificate.certificate_id}</b>", styles['Body']))
        elements.append(Paragraph(f"Country: <b>{certificate.country_name}</b>", styles['Body']))
        elements.append(Paragraph(f"Date of Birth: <b>{certificate.date_of_birth}</b>", styles['Body']))
        elements.append(Paragraph(f"Address: <b>{certificate.address}</b>", styles['Body']))
        elements.append(Paragraph(f"Gender: <b>{certificate.gender}</b>", styles['Body']))
        elements.append(Paragraph(f"Valid Until: <b>{certificate.valid_until}</b>", styles['Body']))
        elements.append(Spacer(1, 0.5 * inch))

        # Issuing Information
        elements.append(Paragraph("Issued by:", styles['Center']))
        elements.append(Paragraph(f"<b>{certificate.generated_by}</b>", styles['Center']))
        elements.append(Spacer(1, 0.5 * inch))

        # QR Code generation
        qr_data = f"Certificate ID: {certificate.certificate_id}"
        qr = qrcode.make(qr_data)
        qr_img = BytesIO()
        qr.save(qr_img, format="PNG")
        qr_img.seek(0)
        img = Image(qr_img, 2 * inch, 2 * inch)
        elements.append(img)

        # Footer
        elements.append(Spacer(1, 0.5 * inch))
        footer = Paragraph("© 2024 CertifyChain. All rights reserved.", styles['Center'])
        elements.append(footer)

        # Building PDF
        doc.build(elements)

        buffer.seek(0)
        response = HttpResponse(buffer, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="certificate_{certificate.certificate_id}.pdf"'
        return response
    
    except Exception as e:
        print(f"Error generating PDF: {e}")
        response = HttpResponse("Error generating PDF", status=500)
        return response

