from django.contrib import admin
from .models import Certificate

admin.site.register(Certificate)