from django.urls import path
from .views import issue_certificate, validate_certificate, generate_pdf_certificate

from .views import generate_certificate

urlpatterns = [
    path('issue/', generate_certificate, name='generate_certificate'),
]

from .views import home, about_us, our_team, how_we_work, download_app,whyus,features

urlpatterns = [
    path('', home, name='home'),
    path('about-us/', about_us, name='about_us'),
    path('our_team/', our_team, name='our_team'),
    path('features/',features,name='features'),
    path('why-us/',whyus,name='why_us'),
    path('how-we-work/', how_we_work, name='how_we_work'),
    path('download-app/', download_app, name='download_app'),
    path('generate/', issue_certificate, name='issue_certificate'),
    path('validate/', validate_certificate, name='validate_certificate'),
    path('pdf/<str:certificate_id>/', generate_pdf_certificate, name='generate_pdf_certificate'),
]
